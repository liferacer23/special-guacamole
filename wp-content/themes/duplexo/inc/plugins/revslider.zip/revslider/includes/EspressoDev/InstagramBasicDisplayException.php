<?php

namespace EspressoDev;

class InstagramBasicDisplayException extends \Exception
{
    // ..
}
