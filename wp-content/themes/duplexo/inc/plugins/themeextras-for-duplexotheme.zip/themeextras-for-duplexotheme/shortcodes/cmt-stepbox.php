<?php
// [cmt-stepbox]
if( !function_exists('cymolthemes_stepbox') ){
function cymolthemes_stepbox( $atts, $content=NULL ){
	
	$return = '';
	
	if( function_exists('vc_map') ){ 
	
	global $cmt_vc_custom_element_stepbox;
	$options_list = cymolthemes_create_options_list($cmt_vc_custom_element_stepbox);
	
	extract( shortcode_atts(
		$options_list
	, $atts ) );
	

		// Heading element
		$return .= cymolthemes_vc_element_heading( get_defined_vars() );
	
		// Getting $args for WP_Query
		$args = cymolthemes_get_query_args( 'box_content', get_defined_vars() );

	
		if( !empty($box_content) ){
		
			$static_boxes = (array) vc_param_group_parse_atts( $box_content );

				
				$return .= '<div class="cymolthemes-boxes-row-wrapper cmt-stepbox-section">';
				$x = 1;
				foreach( $static_boxes as $cmt_box ){
					$staticbox_desc  = ( !empty($cmt_box['static_boxcontent']) ) ? '<div class="cmt-sboxbox-description">'.$cmt_box['static_boxcontent'].'</div>' : '' ;
					
					$staticbox_bicon= do_shortcode('[cmt-sboxicon type="' . $cmt_box['i_type'] . '" icon_linecons="' . $cmt_box['i_icon_linecons'] . '" icon_themify="' . $cmt_box['i_icon_themify'] . '" icon_fontawesome="' . $cmt_box['i_icon_fontawesome'] . '" icon_cmt_duplexo="' . $cmt_box['i_icon_cmt_duplexo'] . '" ]');
					
					$static_boxtitle      = ( !empty($cmt_box['static_boxtitle']) ) ? '<div class="cmt-sboxbox-title"><h5>'.$cmt_box['static_boxtitle'].'</h5></div>' : '' ;
				
					$p_num = array("1", "3", "5", "7","9");
					if (in_array($x, $p_num)) { 
					
						$return .= '
						<div class="cmt-stepsbox cmt-section-wrapper">
							<div class="cmt-sboxbox-iconbox cmt-section-wrapper-cell"> 
									<div class="cmt-sboxbox-icon">
									'.$staticbox_bicon.'
									</div>								
							</div>
							<div class="cmt-sboxbox-content cmt-section-wrapper-cell" >
								'.$static_boxtitle.'
								'.$staticbox_desc.'
							</div>
						</div>
						';
					} else {
						$return .= '
						<div class="cmt-stepsbox cmt-section-wrapper cmt-textalign-right">
							<div class="cmt-sboxbox-content cmt-section-wrapper-cell" >
								'.$static_boxtitle.'
								'.$staticbox_desc.'
							</div>
							<div class="cmt-sboxbox-iconbox cmt-section-wrapper-cell"> 
								<div class="cmt-sboxbox-icon">
								'.$staticbox_bicon.'
								</div>								
							</div>
						</div>
						';
					}						
						
					$x++;
				} // end foreach
				$return .= '</div>';
				
			} // end if
			

		/* Restore original Post Data */
		wp_reset_postdata();
	
} else {
		$return .= '<!-- Visual Composer plugin not installed. Please install it to make this shortcode work. -->';
	}

	return $return;	
	
}
}
add_shortcode( 'cmt-stepbox', 'cymolthemes_stepbox' );