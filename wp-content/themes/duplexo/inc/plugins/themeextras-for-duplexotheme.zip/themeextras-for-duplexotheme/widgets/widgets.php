<?php

// Contact Widget
require CMTTE_DIR . '/widgets/contact-widget.php';

// Recent Posts Widget
require CMTTE_DIR . '/widgets/recent-posts-widget.php';

// Flicker Widget
require CMTTE_DIR . '/widgets/flicker-widget.php';

// Category/Group List Widget
require CMTTE_DIR . '/widgets/category-list.php';

// All Post List Widget
require CMTTE_DIR . '/widgets/all-posts-list.php';

